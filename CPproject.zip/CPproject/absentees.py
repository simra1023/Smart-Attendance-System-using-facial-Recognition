import csv
import os
from datetime import date, datetime

ATTENDANCE_FOLDER = 'attendance'
ALL_STUDENTS_FILE = 'all_students.csv'

def get_today_filename():
    today_str = date.today().strftime('%Y-%m-%d')
    return os.path.join(ATTENDANCE_FOLDER, f'{today_str}.csv')

def load_all_students():
    students = []
    with open(ALL_STUDENTS_FILE, 'r') as f:
        reader = csv.reader(f)
        next(reader, None)  # skip header
        for row in reader:
            if row:
                students.append(row[0].strip())
    return students

def load_present_students(file_path):
    present = set()
    if not os.path.exists(file_path):
        return present

    with open(file_path, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            if 'Name' in row and 'Status' in row:
                if row['Status'].strip().lower() == 'present':
                    present.add(row['Name'].strip())
    return present

def mark_absentees():
    all_students = load_all_students()
    today_file = get_today_filename()
    present_students = load_present_students(today_file)

    absentees = [name for name in all_students if name not in present_students]

    if not absentees:
        print("No absentees to mark.")
        return

    existing_rows = []
    if os.path.exists(today_file):
        with open(today_file, 'r') as f:
            reader = csv.DictReader(f)
            for row in reader:
                existing_rows.append(row)

    now = datetime.now().strftime('%H:%M')
    for name in absentees:
        existing_rows.append({'Name': name, 'Time': now, 'Status': 'Absent'})

    with open(today_file, 'w', newline='') as f:
        fieldnames = ['Name', 'Time', 'Status']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in existing_rows:
            writer.writerow(row)

    print(f"[INFO] Absentees marked successfully in {today_file}")

if __name__ == '__main__':
    mark_absentees()
