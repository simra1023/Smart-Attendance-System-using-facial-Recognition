import tkinter as tk
from tkinter import messagebox
import os

# --- Functions for each button ---
def capture_faces():
    os.system("py capture.py")

def train_faces():
    os.system("py train.py")

def recognize_faces():
    os.system("py recognize.py")

def mark_absentees():
    os.system("py absentees.py")

def show_analytics():
    os.system("py analytics.py")

def exit_app():
    if messagebox.askyesno("Exit", "Are you sure you want to exit?"):
        root.destroy()

# --- Dashboard Window ---
root = tk.Tk()
root.title("Smart Attendance Dashboard")
root.geometry("500x450")
root.config(bg="#1e1e2f")

# --- Title ---
title = tk.Label(root, text="📊 Smart Attendance System", 
                 font=("Arial", 20, "bold"), bg="#1e1e2f", fg="white")
title.pack(pady=20)

# --- Buttons ---
btn_style = {"font": ("Arial", 14, "bold"), "width": 20, "height": 2}

tk.Button(root, text="📸 Capture Faces", bg="#4CAF50", fg="white",
          command=capture_faces, **btn_style).pack(pady=8)

tk.Button(root, text="🛠️ Train Model", bg="#2196F3", fg="white",
          command=train_faces, **btn_style).pack(pady=8)

tk.Button(root, text="👤 Recognize Faces", bg="#9C27B0", fg="white",
          command=recognize_faces, **btn_style).pack(pady=8)

tk.Button(root, text="📋 Mark Absentees", bg="#FF9800", fg="white",
          command=mark_absentees, **btn_style).pack(pady=8)

tk.Button(root, text="📈 Analytics", bg="#FFC107", fg="black",
          command=show_analytics, **btn_style).pack(pady=8)

tk.Button(root, text="❌ Exit", bg="#F44336", fg="white",
          command=exit_app, **btn_style).pack(pady=12)

# --- Run ---
root.mainloop()
