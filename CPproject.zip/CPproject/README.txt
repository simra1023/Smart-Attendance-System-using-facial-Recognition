Capstone Attendance Project - Quick Start

1) Install dependencies:
   pip install opencv-python opencv-contrib-python matplotlib plotly openpyxl reportlab

2) Capture student images:
   py capture_images.py
   - Enter the student's name in the dialog.
   - Press 's' to save frames, 'q' to quit. Capture ~30 images per student.

3) Train the recognizer:
   py train_recognizer.py
   - Generates trainer.yml and labels.pickle

4) Run recognition / attendance:
   py recognize.py
   - Login with staff credentials (staff.csv). Default admin/admin123 works.
   - Recognized students are marked Present. Unknown faces are saved in unknown_faces/.

5) Mark absentees (if needed):
   py absentees.py

6) Analytics (optional):
   py analytics.py
   - Generates overall, weekly and monthly reports (xlsx + pdf) and shows interactive graphs.

NOTE:
- Keep trainer.yml and labels.pickle in the project folder after training.
- If a ZIP is extracted to Windows path with spaces, run commands from that folder (e.g. using PowerShell).
