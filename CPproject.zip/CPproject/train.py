import cv2
import os
import numpy as np
import pickle

face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

BASE_DIR = "dataset"
label_ids = {}
current_id = 0
x_train = []
y_labels = []

for root, dirs, files in os.walk(BASE_DIR):
    for file in files:
        if file.lower().endswith(('jpg','jpeg','png')):
            path = os.path.join(root, file)
            label = os.path.basename(root)

            if label not in label_ids:
                label_ids[label] = current_id
                current_id += 1

            id_ = label_ids[label]
            img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
            if img is None:
                print(f"[WARN] Could not read {path}")
                continue
            faces = face_cascade.detectMultiScale(img, scaleFactor=1.1, minNeighbors=5, minSize=(50,50))
            for (x, y, w, h) in faces:
                roi = img[y:y+h, x:x+w]
                roi_resized = cv2.resize(roi, (200, 200))
                x_train.append(roi_resized)
                y_labels.append(id_)

with open("labels.pickle", "wb") as f:
    pickle.dump(label_ids, f)

recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.train(x_train, np.array(y_labels))
recognizer.save("trainer.yml")
print("[INFO] Training complete. Saved trainer.yml and labels.pickle")

