import cv2
import pickle
import csv
import os
import time
import numpy as np
from datetime import datetime
import tkinter as tk
from tkinter import simpledialog, messagebox

# --- Authentication (fallback if staff.csv missing) ---
STAFF_FILE = "staff.csv"
def authenticate_staff():
    default_staff = {"admin":"admin123"}
    staff = default_staff.copy()
    if os.path.exists(STAFF_FILE):
        try:
            with open(STAFF_FILE, 'r', newline='') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    # accept multiple header variants
                    username = row.get('username') or row.get('Username') or row.get('user') or None
                    password = row.get('password') or row.get('Password') or row.get('pass') or None
                    if username and password:
                        staff[username] = password
        except Exception as e:
            print(f"[WARN] could not read {STAFF_FILE}: {e}")
    root = tk.Tk(); root.withdraw()
    username = simpledialog.askstring("Login", "Enter username:")
    password = simpledialog.askstring("Login", "Enter password:", show="*")
    if username in staff and staff[username] == password:
        messagebox.showinfo("Login", f"Welcome {username}! Access granted.")
        return True
    else:
        messagebox.showerror("Login Failed", "Invalid credentials! Access denied.")
        return False

if not authenticate_staff():
    raise SystemExit(0)

# --- Load recognizer and labels ---
if not os.path.exists('trainer.yml') or not os.path.exists('labels.pickle'):
    messagebox.showerror('Missing Files', 'trainer.yml and/or labels.pickle not found. Run train_recognizer.py first.')
    raise SystemExit(0)

recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read("trainer.yml")

with open("labels.pickle", 'rb') as f:
    original_labels = pickle.load(f)
    labels = {v: k for k, v in original_labels.items()}

# --- Load Haar Cascade ---
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# --- Attendance folder setup ---
date_str = datetime.now().strftime("%Y-%m-%d")
attendance_path = os.path.join("attendance", f"{date_str}.csv")
os.makedirs("attendance", exist_ok=True)

# --- Load all students ---
if not os.path.exists('all_students.csv'):
    messagebox.showerror('Missing', 'all_students.csv not found. Please create or run capture_images.py first.')
    raise SystemExit(0)

with open("all_students.csv", 'r', newline='') as f:
    reader = csv.reader(f)
    all_students = set()
    for i,row in enumerate(reader):
        if i==0: continue
        if row:
            all_students.add(row[0].strip())

present_students = set()

# --- Webcam capture ---
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    messagebox.showerror('Camera Error', 'Could not open webcam. Check camera permissions and device index.')
    raise SystemExit(0)

print("[INFO] Recognizing faces... Press 'q' to quit")

# --- Unknown face tracking ---
last_unknown_time = 0
last_unknown_face = None

def mse(imageA, imageB):
    err = np.sum((imageA.astype("float") - imageB.astype("float")) ** 2)
    err /= float(imageA.shape[0] * imageA.shape[1])
    return err

def apply_clahe(gray):
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
    return clahe.apply(gray)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    gray = apply_clahe(gray)

    faces = face_cascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=6,
        minSize=(100, 100)
    )

    for (x, y, w, h) in faces:
        roi_gray = gray[y:y+h, x:x+w]
        # ensure ROI large enough
        try:
            id_, conf = recognizer.predict(roi_gray)
        except Exception as e:
            print("[WARN] recognizer prediction failed:", e)
            continue

        # Debug info
        print(f"[DEBUG] ID={id_}, Name={labels.get(id_, 'Unknown')}, Conf={conf:.2f}, Size=({w}x{h})")

        if conf <= 70 and w > 120 and h > 120:
            name = labels.get(id_, "Unknown")
            color = (0, 255, 0)
            if name not in present_students:
                present_students.add(name)
                print(f"[MARKED PRESENT] {name}")
        else:
            name = "Unknown"
            color = (0, 0, 255)
            now = time.time()
            if now - last_unknown_time > 10:
                unknown_dir = "unknown_faces"
                os.makedirs(unknown_dir, exist_ok=True)
                face_resized = cv2.resize(roi_gray, (100, 100))
                save_face = True
                if last_unknown_face is not None:
                    error = mse(face_resized, last_unknown_face)
                    if error < 100:
                        save_face = False
                        print("[INFO] Skipped duplicate unknown face.")
                if save_face:
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S%f")
                    fname = os.path.join(unknown_dir, f"unknown_{timestamp}.jpg")
                    cv2.imwrite(fname, face_resized)
                    last_unknown_face = face_resized
                    last_unknown_time = now
                    print(f"[INFO] Unknown face saved: {fname}")

        cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
        cv2.putText(frame, f"{name} ({conf:.0f})", (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, color, 2)

    cv2.imshow("Attendance", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

# --- Save attendance ---
absent_students = all_students - present_students
with open(attendance_path, 'w', newline='') as f:
    writer = csv.writer(f)
    writer.writerow(["Name", "Status"])
    for name in sorted(present_students):
        writer.writerow([name, "Present"])
    for name in sorted(absent_students):
        writer.writerow([name, "Absent"])

print("[INFO] Attendance saved at:", attendance_path)
tk.Tk().withdraw()
messagebox.showinfo("Attendance", "Attendance taken successfully!")
