import cv2
import os
from tkinter import simpledialog, messagebox, Tk
import csv

dataset_dir = "dataset"
os.makedirs(dataset_dir, exist_ok=True)

def update_all_students(name):
    file_path = "all_students.csv"
    if not os.path.exists(file_path):
        with open(file_path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(["Name"])
    # read existing names
    with open(file_path, 'r', newline='') as f:
        reader = csv.reader(f)
        names = [row[0] for i,row in enumerate(reader) if i>0 and row]
    if name not in names:
        with open(file_path, 'a', newline='') as f:
            csv.writer(f).writerow([name])

def capture_images():
    root = Tk()
    root.withdraw()
    name = simpledialog.askstring("Input", "Enter name of person:")
    if not name:
        messagebox.showerror("Error", "Name is required")
        return
    person_dir = os.path.join(dataset_dir, name)
    os.makedirs(person_dir, exist_ok=True)
    update_all_students(name)
    cap = cv2.VideoCapture(0)
    count=0
    print("[INFO] Press 's' to save an image, 'q' to quit (or stop after 30 saves).")
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        cv2.imshow("Capture - Press 's' to save, 'q' to quit", frame)
        key = cv2.waitKey(1) & 0xFF
        if key == ord('s'):
            filename = os.path.join(person_dir, f"{name}_{count}.jpg")
            cv2.imwrite(filename, frame)
            count += 1
            print(f"[INFO] Saved {filename}")
        elif key == ord('q') or count>=30:
            break
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    capture_images()
