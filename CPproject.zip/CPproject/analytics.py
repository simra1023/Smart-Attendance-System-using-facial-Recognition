import os
import csv
from datetime import datetime
import plotly.graph_objects as go
from openpyxl import Workbook
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet

ATTENDANCE_FOLDER = "attendance"
ALL_STUDENTS_FILE = "all_students.csv"

def load_all_students():
    students = []
    with open(ALL_STUDENTS_FILE, 'r') as f:
        reader = csv.reader(f)
        for i, row in enumerate(reader):
            if i > 0 and row:  # skip header
                students.append(row[0])
    return students

def load_attendance_files():
    records = []
    for file in os.listdir(ATTENDANCE_FOLDER):
        if file.endswith(".csv"):
            date_str = file.replace(".csv", "")
            try:
                file_date = datetime.strptime(date_str, "%Y-%m-%d").date()
            except ValueError:
                continue

            with open(os.path.join(ATTENDANCE_FOLDER, file), 'r') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    records.append({
                        "date": file_date,
                        "name": row.get("Name"),
                        "status": row.get("Status")
                    })
    return records

def calculate_percentages(records, all_students, mode="overall"):
    summary = {}
    for student in all_students:
        summary[student] = {}
    for record in records:
        if mode == "weekly":
            key = f"Week-{record['date'].isocalendar()[1]}"
        elif mode == "monthly":
            key = record["date"].strftime("%Y-%m")
        else:
            key = "Overall"
        for student in all_students:
            if key not in summary[student]:
                summary[student][key] = {"Present": 0, "Absent": 0}
        if record["name"] in all_students:
            status = record["status"]
            summary[record["name"]][key][status] += 1
    percentages = {}
    for student, periods in summary.items():
        percentages[student] = {}
        for period, counts in periods.items():
            total = counts["Present"] + counts["Absent"]
            if total > 0:
                percentages[student][period] = round((counts["Present"] / total) * 100, 2)
            else:
                percentages[student][period] = 0.0
    return percentages

def plot_interactive(percentages, mode="overall"):
    data = []
    for student, periods in percentages.items():
        x = list(periods.keys())
        y = list(periods.values())
        data.append(go.Bar(name=student, x=x, y=y))
    fig = go.Figure(data=data)
    fig.update_layout(
        barmode="group",
        title=f"Attendance Report ({mode.title()})",
        xaxis_title="Period",
        yaxis_title="Attendance %",
        yaxis=dict(range=[0, 100])
    )
    fig.show()

def export_to_excel(percentages, filename):
    wb = Workbook()
    ws = wb.active
    ws.title = "Attendance Report"
    all_periods = set()
    for student, periods in percentages.items():
        all_periods.update(periods.keys())
    all_periods = sorted(all_periods)
    ws.append(["Name"] + all_periods)
    for student, periods in percentages.items():
        row = [student]
        for p in all_periods:
            row.append(periods.get(p, 0))
        ws.append(row)
    wb.save(filename)
    print(f"[INFO] Excel report saved: {filename}")

def export_to_pdf(percentages, filename):
    doc = SimpleDocTemplate(filename, pagesize=A4)
    elements = []
    styles = getSampleStyleSheet()
    elements.append(Paragraph("Attendance Report", styles['Title']))
    elements.append(Spacer(1, 12))
    all_periods = set()
    for student, periods in percentages.items():
        all_periods.update(periods.keys())
    all_periods = sorted(all_periods)
    data = [["Name"] + all_periods]
    for student, periods in percentages.items():
        row = [student]
        for p in all_periods:
            row.append(str(percentages[student].get(p, 0)) + "%")
        data.append(row)
    table = Table(data, repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.grey),
        ("TEXTCOLOR", (0,0), (-1,0), colors.whitesmoke),
        ("ALIGN", (0,0), (-1,-1), "CENTER"),
        ("GRID", (0,0), (-1,-1), 1, colors.black),
        ("BACKGROUND", (0,1), (-1,-1), colors.beige),
    ]))
    elements.append(table)
    doc.build(elements)
    print(f"[INFO] PDF report saved: {filename}")

if __name__ == "__main__":
    all_students = load_all_students()
    records = load_attendance_files()
    for mode in ["overall", "weekly", "monthly"]:
        print(f"\n[INFO] Generating {mode.title()} Report...")
        percentages = calculate_percentages(records, all_students, mode=mode)
        plot_interactive(percentages, mode=mode)
        export_to_excel(percentages, f"{mode}_report.xlsx")
        export_to_pdf(percentages, f"{mode}_report.pdf")
